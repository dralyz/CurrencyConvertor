let country_list = {
    "KRW" : "KR",
    "EUR" : "FR",
    "USD" : "US",
    "JPY" : "JP",
}
